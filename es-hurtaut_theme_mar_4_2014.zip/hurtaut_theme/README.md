This set of themes was created by Florian Hurtaut.

Included are some of the materials used to make this theme (template.psd, Controllers.ai) and a nice splashscreen for use with RetroPie.

To install, put the ".emulationstation" folder in your home directory ($HOME or "~" in Linux, %HOMEPATH% on Windows).

Contains themes for:
	atari2600
	cavestory
	cps2
	doom
	gba
	gbc
	mame
	genesis (megadrive)
	neogeo
	nes
	turbografx-16 (pcengine)
	psx
	snes
