Nes mini theme launch screens for Retropie by Ruckage
Version 1
08/07/2017

A set of custom launch screens designed to be used with my Nes mini theme

--------------------------------------------------------------------------------

License

A great deal of work has been put into the art used in these splashscreens so please do not use the graphics I have created in any other projects.

Commercial distribution is prohibited

--------------------------------------------------------------------------------

HOW TO USE
----------

There are 3 folder that correspond to different aspect ratios (16x9, 4x3, NTSC).

Copy the contents of the folder that matches your screen aspect ratio to: '/opt/retropie/configs/' 
